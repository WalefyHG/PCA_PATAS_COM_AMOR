import News from "../../../screens/users/News";

export default function UserNews(){
    return (
        <News />
    )
}