import News from "../../../presentation/screens/users/News";

export default function UserNews() {
    return (
        <News />
    )
}