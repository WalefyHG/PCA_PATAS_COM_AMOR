import Profile from "../../../presentation/screens/users/Profile";

export default function UserProfile() {
    return (
        <Profile />
    )
}
