import Profile from "../../../screens/users/Profile";

export default function UserProfile(){
    return (
        <Profile />
    )
}
