import Settings from "../../../presentation/screens/settings/Settings";

export default function UserSettings() {
    return (
        <Settings />
    )
}