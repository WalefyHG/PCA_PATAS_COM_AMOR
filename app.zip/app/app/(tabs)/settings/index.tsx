import Settings from "../../../screens/settings/Settings";

export default function UserSettings() {
    return (
        <Settings />
    )
}