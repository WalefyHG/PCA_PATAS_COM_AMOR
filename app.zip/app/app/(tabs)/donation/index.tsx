import { DonationScreen } from "@/app/presentation/screens/Donation";


export default function UserAbout() {
    return (
        <DonationScreen />
    )
}