import Home from "../../../presentation/screens/users/Home";

export default function UserHome() {
    return (
        <Home />
    )
}