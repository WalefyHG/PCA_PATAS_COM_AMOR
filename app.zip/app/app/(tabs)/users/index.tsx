import Home from "../../../screens/users/Home";

export default function UserHome(){
    return (
        <Home />
    )
}