import About from "../../../screens/users/About";

export default function UserAbout() {
    return (
        <About />
    )
}